CREATE TABLE Person (
    id SERIAL PRIMARY KEY NOT NULL, --auto increment by 1
    name VARCHAR (50) NOT NULL,
    size INT NOT NULL,
    height INT NOT NULL,
    type VARCHAR(20) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(40),
    link VARCHAR(225),
    createdDate TIMESTAMP NOT NULL DEFAULT  CURRENT_TIMESTAMP
);


INSERT INTO Person(name, size, height, type)
VALUES ('William', 60, 170, 'A');


INSERT INTO Person(name, size, height, type, phone, email, link)
VALUES (test, 30, 30,b,,,)

DELETE FROM Person
WHERE id="1"
