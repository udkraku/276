// // var a = window.prompt("tell me your name", "Name");
// // window.alert("hello " + a);
//
//
// // func1(1,2,3);
//
//
// // function func1(a,b,c){
// //   console.log(a+b+c);
// // }
// //
// // var func2 = function(){
// //   console.log("hello world");
// // }
//
// // func2();
//
//
// function asc(a,b){
//   return a-b
// }
//
// var arr = [1,22,13,54,5,69];
// arr.sort(asc);
//
// // for (item in arr){
// //   console.log(arr[item]);
// // }
//
// var x = arr.every(function(val){
//   return val >3;
// });
//
// console.log(x)
//
// // var person = {
// //   firstname: "bob",
// //   lastname: "smith",
// //   id: 5555,
// //   fullname: function(){
// //       return this.firstname + " " + this.lastname;
// //   }
// // }
//
// function Person(f,l,i,a){
//   this.firstname = f;
//   this.lastname = l;
//   this.age = a;
//   this.id = i;
// }

// function runcommand(){
//   document.getElementsByTagName("h1")[0].innerHTML = "ADD Users";
// }
//
// document.getElementById("button").onclick = runcommand;
// //document.getElementById("button").onclick = (evt)=>{console.log("hello")};
//
//
// document.getElementById("button").addEventListener('click',(evt)=>{console.log("hello")});
// document.getElementById("button").addEventListener('click', (evt)=>(console.log("world")));
//
// window.addEventListener('keypress', (evt)=>(console.log(evt.keyCode)));


// document.getElementById("addBtn").onclick = (evt)=>{
//   window.location="/";
// };


///////////////////////////////////////////////////
function makeTable(element){


  //delete table rows
  var size = document.getElementsByClassName("dbRow").length;
  if(size > 5){
    size = size/5
  }

  var table = document.getElementById("displayTable");

  var rowCount = table.rows.length;
  if(rowCount != 0){
    for (var row = 0; row < rowCount; row ++){
      table.deleteRow((rowCount-1)-row);
    }
  }

  //create thead
  var head = table.createTHead();
  for (var row = 0; row < size; row++){
    var head_init = head.insertRow(row);
    if(row == 0){
      for (var col = 0; col <= size; col++){
        if(col == 0){
          emptyCol = head_init.insertCell(col).outerHTML = '<th>&nbsp;</th>';

        }
        else{ //head at first row
          head_init.insertCell(col).outerHTML = '<th>'+col+'</th>';
          head.rows[row].cells[col].className='col';
        }
      }
    }
  }

  //insert table row
  var body = table.createTBody();
  for (var row = 0; row < size; row ++){
    var row_init = body.insertRow(row);
    for (var col = 0; col <= size; col++){
      if(col == 0){
        row_init.insertCell(col).outerHTML = '<th>'+(row+1)+'</th>';
        body.rows[row].cells[col].className='row';
      }
      else{
        row_init.insertCell(col).innerHTML = '<td></td>';
        body.rows[row].cells[col].id = ''+row+'_'+(col-1)+'';
        body.rows[row].cells[col].className='content';
        body.rows[row].cells[col].setAttribute('onclick', 'changeState(this)')
      }
    }
  }
}

makeTable()
