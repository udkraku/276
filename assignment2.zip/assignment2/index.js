const express = require('express')              //external library import
const path = require('path')

const PORT = process.env.PORT || 5000

const {Pool} = require('pg');
var pool;
pool = new Pool({
  //connectionString: 'postgres://postgres:root@localhost/users' //scheme://usr:name@serverurl/database
  connectionString: process.env.DATABASE_URL //postgresql-deep-98816 as DATABASE_URL

})

var app = express();
app.use(express.json()); //give serve ability to work with json
app.use(express.urlencoded({extended:false}));

app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs'); //embeded java script

//---------------------------------------------------------------
//app.get('/', (req, res) => res.render('pages/index'));
app.get('/database', (req,res)=> {
  //var data ={results: [2,3,4,5,6]};
  var getUsersQuery = "SELECT * FROM person";
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows}
    res.render('pages/db', results);
  })
  //res.render('pages/db', data);
});
//---------------------------------------------------------------
//---------------------------------------------------------------
app.get('/sortUserAsc', (req,res)=> {
  var getUsersQuery = "SELECT * FROM person ORDER BY createddate ASC";
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows}
    res.render('pages/db', results);
  })

});
//---------------------------------------------------------------
//---------------------------------------------------------------
app.get('/sortUserDesc', (req,res)=> {
  var getUsersQuery = "SELECT * FROM person ORDER BY createddate DESC";
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows}
    res.render('pages/db', results);
  })

});
//---------------------------------------------------------------
//---------------------------------------------------------------
app.get('/sortTypeAsc', (req,res)=> {
  var getUsersQuery = "SELECT * FROM person ORDER BY type ASC";
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows}
    res.render('pages/db', results);
  })

});
//---------------------------------------------------------------
//---------------------------------------------------------------
app.get('/sortTypeDesc', (req,res)=> {
  var getUsersQuery = "SELECT * FROM person ORDER BY type DESC";
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows}
    res.render('pages/db', results);
  })

});
//---------------------------------------------------------------
//---------------------------------------------------------------
app.get('/sortNameAsc', (req,res)=> {
  var getUsersQuery = "SELECT * FROM person ORDER BY name ASC";
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows}
    res.render('pages/db', results);
  })

});
//---------------------------------------------------------------
//---------------------------------------------------------------
app.get('/sortNameDesc', (req,res)=> {
  var getUsersQuery = "SELECT * FROM person ORDER BY name DESC";
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows}
    res.render('pages/db', results);
  })

});
//---------------------------------------------------------------
//---------------------------------------------------------------
app.get('/sortSizeAsc', (req,res)=> {
  var getUsersQuery = "SELECT * FROM person ORDER BY size ASC";
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows}
    res.render('pages/db', results);
  })

});
//---------------------------------------------------------------
//---------------------------------------------------------------
app.get('/sortSizeDesc', (req,res)=> {
  var getUsersQuery = "SELECT * FROM person ORDER BY size DESC";
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows}
    res.render('pages/db', results);
  })

});
//---------------------------------------------------------------

//---------------------------------------------------------------
app.get('/sortHeightAsc', (req,res)=> {
  var getUsersQuery = "SELECT * FROM person ORDER BY height ASC";
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows}
    res.render('pages/db', results);
  })

});
//---------------------------------------------------------------
//---------------------------------------------------------------
app.get('/sortHeightDesc', (req,res)=> {
  var getUsersQuery = "SELECT * FROM person ORDER BY height DESC";
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows}
    res.render('pages/db', results);
  })

});
//---------------------------------------------------------------
//---------------------------------------------------------------
//app.get('/', (req, res) => res.render('pages/index'));
app.get('/', (req,res)=> {
  //var data ={results: [2,3,4,5,6]};
  var getUsersQuery = "SELECT COUNT(*) OVER(), p.* FROM person p";
  //var getNumOfRows = "SELECT COUNT(*) OVER(), p.* FROM person p";
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows};
    res.render('pages/index', results);
  })
});
//---------------------------------------------------------------
//---------------------------------------------------------------
app.get('/sortGroup', (req,res)=> {
  //var data ={results: [2,3,4,5,6]};
  var getUsersQuery = "SELECT COUNT(*) OVER(), p.* FROM person p ORDER BY type";
  //var getNumOfRows = "SELECT COUNT(*) OVER(), p.* FROM person p";
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows};
    res.render('pages/index', results);
  })
});
//---------------------------------------------------------------
//---------------------------------------------------------------
app.get('/insertUser', (req,res)=> {

  // var getUsersQuery = "SELECT * FROM person";
  // pool.query(getUsersQuery, (error, result) => {
  //   if(error)
  //     res.end(error);
  //   var results = {'rows': result.rows}
  //   res.render('pages/db', results);
  // })
  res.render('pages/insert')

});
//---------------------------------------------------------------
app.get('/updateUser', (req,res)=> {
  var id = req.query.id;
  var getUsersQuery = "SELECT * FROM person WHERE id='"+id+"';";
  console.log(getUsersQuery);
  pool.query(getUsersQuery, (error, result) => {
    if(error)
      res.end(error);
    var results = {'rows': result.rows}
    res.render('pages/update', results);
  })
  //res.render('pages/update')

});
//---------------------------------------------------------------
//---------------------------------------------------------------
app.post('/updateUser', (req,res)=>{
  console.log("post request for /updateUser")
  var person ={
    id: req.body.id,
    name: req.body.name,
    size: req.body.size,
    height: req.body.height,
    type: req.body.type,
    phone: req.body.phone,
    email: req.body.email,
    link: req.body.link
  }
  console.log(person);

  var updateUserQuery = "UPDATE Person SET "
                        +"name='"+person.name+"',"
                        +"size='"+ person.size+"',"
                        +"height='"+person.height+"',"
                        +"type='"+person.type+"',"
                        +"phone='"+person.phone+"',"
                        +"email='"+person.email+"',"
                        +"link='"+person.link+"'"
                        +"WHERE id='"+person.id+"';";
  console.log(updateUserQuery);
  pool.query(updateUserQuery, (error, result) => {
    if(error)
      res.end(error);

    // var results = {'rows': result.rows}
    // res.render('pages/db', results);
    res.redirect('/database');
  })
})
//---------------------------------------------------------------
// app.post('/adduser', (req,res)=>{
//   console.log("post request for /adduser");
//   var uname = req.body.uname;
//   var age = req.body.age;
//   res.send(`username: ${uname}, age: ${age}`);
// });
app.get('/users/:id', (req,res)=>{
  var uid = req.params.id;
  console.log(req.params.id);
  //search the database using the uid
  res.send("got it!")
})


//---------------------------------------------------------------
app.post('/insertUser', (req,res)=>{
  console.log("post request for /insertUser")
  var person ={
    name: req.body.name,
    size: req.body.size,
    height: req.body.height,
    type: req.body.type,
    phone: req.body.phone,
    email: req.body.email,
    link: req.body.link
  }
  console.log(person);

  var insertUserQuery = "INSERT INTO Person(name, size, height, type, phone, email, link)VALUES ('"
                        +person.name+"',"+ person.size
                        +","+person.height+",'"+person.type
                        +"','"+person.phone+"','"+person.email
                        +"','"+person.link
                        +"')";
  console.log(insertUserQuery);
  pool.query(insertUserQuery, (error, result) => {
    if(error)
      res.end(error);

    // var results = {'rows': result.rows}
    // res.render('pages/db', results);
    res.redirect('/database');
  })
})
//---------------------------------------------------------------

//---------------------------------------------------------------
app.post('/deleteUser', (req,res)=>{
  console.log("post request for /deleteUser")
  var person ={
    id: req.body.id,
  }
  console.log(person);

  var deleteUserQuery = "DELETE FROM Person WHERE id="+person.id+";";

  console.log(deleteUserQuery);
  pool.query(deleteUserQuery, (error, result) => {
    if(error)
      res.end(error);
    res.redirect('/database');
  })
})
//---------------------------------------------------------------
//---------------------------------------------------------------

//---------------------------------------------------------------
//---------------------------------------------------------------
app.listen(PORT, () => console.log(`Listening on ${ PORT }`));
